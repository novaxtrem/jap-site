<?php 
        
    private    $dbhost = 'remotemysql.com:3306';
    private    $dbuser = 'nN3gpTO4n0';
    private    $dbpass = 'mOlXuDZFaT';
    private    $conn = mysqli_connect($dbhost, $dbuser, $dbpass);

        if (!$conn) {
            die('Could not connect: '.mysqli_error());
            echo ('fallo');
        } else {
            echo('Connected successfully');
        }
        
        return $conn ;
       // mysqli_close($conn);

?>