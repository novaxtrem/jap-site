<?php

    //Create connection
 
 header('Access-Control-Allow-Origin: *');

     $dbhost = 'remotemysql.com:3306';
        $dbuser = 'nN3gpTO4n0';
        $dbpass = '2gkHaxV7Xr';
        $dbname = 'nN3gpTO4n0';
        $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

        if (!$conn) {
            die('Could not connect: '.mysqli_error());
            echo ('fallo');
        } else {
         //   echo('Connected successfully');
        }

      $name = $_POST['name'];
      $lastname = $_POST['last_name'];
      $age= $_POST['age'];
      $imgProfile = $_POST['image_profile'];
      $phoneNum = $_POST['phone_num'];
      $email = $_POST['email'];
      $pass = $_POST['password'];

      $q = "INSERT INTO usuarios (id, name, last_name, age, image_profile, phone_num, email, password) VALUES 
      (DEFAULT, '$name', '$lastname', '$age', '$imgProfile', '$phoneNum','$email','$pass');";
      $query = mysqli_query($conn, $q);

    if($query){
        echo json_encode("ok");
        //echo json_encode("Data Inserted Successfully");
    }else {
        var_dump(mysqli_error($conn));
        echo $query;
    }
     
?>